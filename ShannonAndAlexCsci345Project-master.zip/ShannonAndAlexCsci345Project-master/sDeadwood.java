// Project Group 1 
// Members: Shannon Melious and Alex Petralia
// Assignment 3 -- GUI based
// CSCI 345-Section B Spring 2018

import java.util.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Arrays; 
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import java.io.File;

// Deadwood class:
public class Deadwood{

   // Main method:   
   public static void main(String[] args){
   
      //--------------------------------game setup------------------------------------------
      
      //Initialize scenes and rooms from xml files
      Document doc = null;
      ParseCardXML parsing = new ParseCardXML();
      
      Document docB = null;
      ParseBoardXML parser = new ParseBoardXML();
      
      ArrayList<Scene> sceneDeck = new ArrayList<Scene>();
      sceneDeck = null;
      
      ArrayList<Room> locations = new ArrayList<Room>();
      locations = null;
      
      try{
         
         //Add information from the parsers into the scenes and rooms
         doc = parsing.getDocFromFile("cards.xml");
         sceneDeck = parsing.createSceneDeck(doc);
      
         docB = parser.getDocFromFile("board.xml");
         locations = parser.createRooms(docB);
         
      } catch(Exception ex){
         System.out.println("Error = "+ex);
      }
         
      
      //Set location of Trailers and Casting Office
      Room trailer = new Room();
      Room castingOffice = new Room();
      
      for(int i=0; i < locations.size(); i++){
         if("Trailer".equals(locations.get(i).getName())){
            trailer = locations.get(i);
         }
         else if("Casting Office".equals(locations.get(i).getName())){
            castingOffice = locations.get(i);
         }
      }
      
      //Set attributes for the adjcent rooms (of each location)
      for(int i=0; i < locations.size(); i++){
         ArrayList<Room> locAdjRooms = locations.get(i).getAdjRooms();
         
         for(int j=0; j < locAdjRooms.size(); j++){
            Room anAdjRoom = locAdjRooms.get(j);
            
            for(int k=0; k <locations.size(); k++){
               if((anAdjRoom.getName()).equals(locations.get(k).getName())){
               
                  anAdjRoom.setRoles(locations.get(k).getRoles());
                  anAdjRoom.setUpgrades(locations.get(k).getUpgrades());
                  anAdjRoom.setShots(locations.get(k).getShots());
                  anAdjRoom.setAdjRooms(locations.get(k).getAdjRooms());
                  anAdjRoom.setScene(locations.get(k).getCurrentScene());
                  anAdjRoom.setNumShots(locations.get(k).getNumShots());
                  anAdjRoom.setX(locations.get(k).getX());
                  anAdjRoom.setY(locations.get(k).getY());
                  anAdjRoom.setH(locations.get(k).getH());
                  anAdjRoom.setW(locations.get(k).getW());
               }
            }
         }
      }
   
      
      //Ask user for number of players
      Scanner reader = new Scanner(System.in);
      System.out.println("How many players? [2 to 8 Players]");
      int n = reader.nextInt();
      while(n < 2 || n > 8){
         System.out.println("You entered " + n + " player(s). Invalid, please choose 2 to 8 players.");         
         n = reader.nextInt();
      }
      System.out.println("Okay, " + n + " players.");
      String[] allColors = new String[n];
      
      //Main Lists
      ArrayList<Player> allP = new ArrayList<Player>();
      ArrayList<Room> allR = new ArrayList<Room>();
      int totalDays = 0;
      
      //Set number of days based on number of players
      if((n == 2) || (n == 3)){
         totalDays = 3;
      }else{
         totalDays = 4;
      }
      
      //Initialize prices for upgrades
      int[][] famePrices = new int[7][1];
      int[][] moneyPrices = new int[7][1];
      famePrices[2][0] = 5;
      famePrices[3][0] = 10;
      famePrices[4][0] = 15;
      famePrices[5][0] = 20;
      famePrices[6][0] = 25;
      moneyPrices[2][0] = 4;
      moneyPrices[3][0] = 10;
      moneyPrices[4][0] = 18;
      moneyPrices[5][0] = 28;
      moneyPrices[6][0] = 40;
      
      ///---------------------------------------------****EDIT start****-------------------------------------------
      
      //Players choose their die colors
      ArrayList<String> allColorsStatic = new ArrayList<>(Arrays.asList("red", "orange", "yellow", "green", "blue", "purple", "pink", "black")); //list for reference only
      ArrayList<String> allColorsTemp = new ArrayList<>(Arrays.asList("red", "orange", "yellow", "green", "blue", "purple", "pink", "black")); //list to use remove() on
      for(int i = 0; i < n; i++){
         System.out.println("Player " + (i + 1) + " choose your color: [ red, orange, yellow, green, blue, purple, pink, or black ]");
         String colorIn = reader.next();
         
         //if a valid color but already taken
         while(allColorsStatic.contains(colorIn) && !allColorsTemp.contains(colorIn)){
            System.out.print("Sorry the color " + colorIn + " is already taken, choose from ");
            for(int g = 0; g < allColorsTemp.size(); g++){
               if(g == allColorsTemp.size() - 1){
                  System.out.println("or " + allColorsTemp.get(g) + ".");
                  //System.out.println();
               }else{
                  System.out.print(allColorsTemp.get(g) + ", ");
               }
            }
            String colorIn2 = reader.next();
            colorIn = colorIn2;
         }
         //if invalid color
         while(!allColorsStatic.contains(colorIn)){
            System.out.println("You entered " + colorIn + ". Invalid, please choose: red, orange, yellow, green, blue, purple, pink, or black as a color.");
            String colorIn2 = reader.next();
            colorIn = colorIn2;
         }
         //if valid color
         if(allColorsStatic.contains(colorIn)){
            allColorsTemp.remove(colorIn);
         }
         
         allColors[i] = colorIn;
         ///---------------------------------------------****EDIT end****-------------------------------------------
      
         Player newPlayer = new Player();
         
         //MY EDIT: Initialize rank, money, and fame for each player
         if(n <= 4){
            newPlayer.setColor(colorIn);
            newPlayer.setRank(1);
            newPlayer.setMoney(0);
            newPlayer.setFame(0);
         } 
         else if(n == 5){
            newPlayer.setColor(colorIn);
            newPlayer.setRank(1);
            newPlayer.setMoney(0);
            newPlayer.setFame(2);
         }
         else if(n == 6){
            newPlayer.setColor(colorIn);
            newPlayer.setRank(1);
            newPlayer.setMoney(0);
            newPlayer.setFame(4);
         }
         else if(n > 6){
            newPlayer.setColor(colorIn);
            newPlayer.setRank(2);
            newPlayer.setMoney(0);
            newPlayer.setFame(0);
         }
         
         //Set players initial location to trailer
         newPlayer.move(trailer);
         allP.add(newPlayer);  
      }     
      
      //-------------------------------------------------------------------------------------
      
   
      //------------------Day Cycle  AND turn rotations for each player-------------------------------------
      for(int daysLeft = totalDays; daysLeft >= 0; daysLeft--){
      
         // set number of scenes to be the amount of rooms (w/o trailer or casting office)
         int sceneCounter = (locations.size() - 2);
         
         if(daysLeft != totalDays && daysLeft != 0){
            System.out.println("---------------------------------------------");
            System.out.println("------------ Days Left: " + daysLeft + " ----------------------");   
            System.out.println("---------------------------------------------");
         
         }else if(daysLeft == 0){
            System.out.println("---------------------------------------------");
            System.out.println("------------ Days Left 0: Last Day ----------");   
            System.out.println("---------------------------------------------");
         }
      
         while(sceneCounter > 1){
            for(int j = 0; j < n; j++){
               if(j >= 0){ ///****EDIT**** changed = to >=
                  System.out.println("---------------------------------------------");
                  System.out.println("Okay it's now Player " + (j + 1) + "'s turn.");
                  System.out.println("---------------------------------------------");
               }
               Player curPlayer = allP.get(j);
               System.out.println("Player " + (j + 1) + "'s color: " + curPlayer.getColor());
            
            //--------------1. move and/or take on role------------------------------------------
            
            //MY EDIT: Player can only move if they are not working on a role
               if(curPlayer.getHasRole() == false){
               
                  System.out.println("Player " + (j + 1) + " will you choose to move? [yes/no]");
                  String m = reader.next();
               
               //If player wants to move, update their location to the room of their choice
                  if(m.equals("yes")){
                     ArrayList<Room> neighbors = curPlayer.getCurrentRoom().getAdjRooms();
                     System.out.println("You are currently in "+curPlayer.getCurrentRoom().getName());
                     System.out.println("Which room will you move to?");
                  
                     for(int k = 0; k < neighbors.size(); k++){
                        System.out.println(neighbors.get(k).getName());
                     }
                  
                     String r = reader.next();
                     for(int p = 0; p < neighbors.size(); p++){
                        if(r.equals(neighbors.get(p).getName())){
                           curPlayer.move(neighbors.get(p));
                        }
                     }
                     System.out.println("You have successfully moved to "+curPlayer.getCurrentRoom().getName());
                  
                  }
               }
            //If player doesn't have a role, give them the option to take one
               if(curPlayer.getHasRole() == false){
                  System.out.println();
               
               //MY EDIT: If they are not in trailer or casting office, then give option to take a role
                  if((curPlayer.getCurrentRoom().getName()) != "Trailer"){ 
                     if((curPlayer.getCurrentRoom().getName()) != "Casting Office"){
                     
                        System.out.println("Player " + (j + 1) + " will you choose to take a role? [yes/no]");
                        String ans = reader.next();
                        if(ans.equals("yes")){
                           System.out.println("Your current rank is "+curPlayer.getRank());
                           System.out.println("Which role do you choose?");
                           
                           for(int r=0; r < sceneDeck.size(); r++){
                              curPlayer.getCurrentRoom().setScene(sceneDeck.get(r));
                           }
                        
                        //Set a scene in the room of the player 
                           curPlayer.setCurrentScene(curPlayer.getCurrentRoom().getCurrentScene());
                        
                        //Get the possible roles that the players can choose from
                           ArrayList<Role> possibleRoles = new ArrayList<Role>();
                           possibleRoles = curPlayer.getCurrentRoom().getRoles();
                        
                           ArrayList<Role> cardRoles = curPlayer.getCurrentRoom().getCurrentScene().getRoles();
                        
                           for(int r = 0; r < cardRoles.size(); r++){
                              possibleRoles.add(cardRoles.get(r));
                           }
                        
                           if(possibleRoles.size() > 0){
                              for(int l = 0; l < possibleRoles.size(); l++){
                                 if(curPlayer.getRank() >= possibleRoles.get(l).getReqRank() && possibleRoles.get(l).checkAvailability() == true){
                                    System.out.println(possibleRoles.get(l).getRoleName());
                                 }
                              }
                           }
                           
                           else if(possibleRoles.size() == 0){
                              System.out.println("There are no available roles.");
                           }
                        
                        //Set player's role to their choice (MY EDIT: change availability of role)
                           String choice = reader.next() + " " +reader.next();
                           for(int l = 0; l < possibleRoles.size(); l++){
                              if(choice.equals(possibleRoles.get(l).getRoleName())){
                                 curPlayer.setCurrentRole(possibleRoles.get(l));
                                 possibleRoles.get(l).setAvailability(false);
                              }
                           }
                        
                           curPlayer.getCurrentRole().setReqRoll(curPlayer.getCurrentScene().getBudget());
                        
                           curPlayer.setHasRole(true);
                        
                        }
                     }
                  }  
               }
            //-------------------------------------------------------------------------------------
            
            
            //--------------------------------2. roll or rehearse for role-------------------------
            
            //If the player has a role, let them choose whether to act or rehearse
               if(curPlayer.getHasRole() == true){
                  Role curRole = curPlayer.getCurrentRole();
                  curRole.setReqRoll(curPlayer.getCurrentScene().getBudget());
                  System.out.println("Player " + (j + 1) + " you currently have role called '" + curRole.getRoleName() + "'.");
                  System.out.println("The role has a required roll of " + curRole.getReqRoll() + " and you have " + curPlayer.getRehearseTokens() + " rehearse tokens for this role. ");  
                  System.out.println("Will you choose to act(roll) or rehearse for your role? [act/rehearse]");
                  String in1 = reader.next();
               
                  if(in1.equals("act")){
                  
                  //Prepare dice roll
                     Random rand  = new Random();
                     int num1 = rand.nextInt(6) + 1;
                     if(curPlayer.getCurrentRole().getType().equals("On-Card")){
                     //Player says line
                        System.out.println("Player " + (j + 1) + "'s Line: ''" + curPlayer.getCurrentRole().getLine() + "''");
                        if(num1 + curPlayer.getRehearseTokens() >= curPlayer.getCurrentRole().getReqRoll()){
                        //Rewards for success
                           curPlayer.setRehearseTokens(-(curPlayer.getRehearseTokens())); //resets rehearse tokens
                        
                           curPlayer.setFame(2); ///****EDIT***
                           System.out.println("Congrats Player " + (j + 1) + "! your role was a "  //EDIT******
                              + "success and you earned 2 fame."); //EDIT******
                        
                           System.out.println("Your fame is now " + curPlayer.getFame());
                        
                        //Advance scene
                           curPlayer.getCurrentRoom().setNumShots(-1);
                        
                        }else{
                           System.out.println("Sorry Player " + (j + 1) + ", you failed your role and will earn nothing.");
                        }
                     
                     }else if(curPlayer.currentRole.getType().equals("Off-Card")){
                     //Player says line
                        System.out.println("Player " + (j + 1) + "'s Line: ''" + curPlayer.getCurrentRole().getLine() + "''");
                        if(num1 + curPlayer.getRehearseTokens() >= curPlayer.getCurrentRole().getReqRoll()){
                        //Rewards for success
                           curPlayer.setRehearseTokens(-(curPlayer.getRehearseTokens())); //resets rehearse tokens
                           curPlayer.setFame(1); ///****EDIT****
                           curPlayer.setMoney(1); ///****EDIT****
                           System.out.println("Congrats Player " + (j + 1) + "! your role was a success and you earned "  
                              + "1 fame and $1.");
                           System.out.println("Your fame is now " + curPlayer.getFame());
                           System.out.println("Your money is equal to $" + curPlayer.getMoney());
                        
                        //Advance scene
                           curPlayer.getCurrentRoom().setNumShots(-1);
                        
                        }else{
                           curPlayer.setMoney(1);
                           System.out.println("Sorry Player " + (j + 1) + ", you failed your role but you will still earn $1 since this is an off-card role.");
                        }
                     }
                  
                  //Update rehearsal token count if they choose to rehearse
                  }else if(in1.equals("rehearse")){
                     curPlayer.setRehearseTokens(1);
                  }
               }
            
            //No more shots left of the scene, pay wrap bonus
               if(curPlayer.getCurrentRoom().getNumShots() == 0){
                  
                  //No more shots, so scene finished --> reduce the scene counter by 1
                  sceneCounter = sceneCounter - 1;
                  if(curPlayer.getHasRole() == true){
                     if(curPlayer.getCurrentRole().getType() == "On-Card"){
                        int numDie = curPlayer.getCurrentRole().getCurrentScene().getBudget();
                        int[] dieRolls = new int[numDie];
                     //Roll number of die equal to budget of current scene
                        for(int i=0; i < numDie; i++){
                           Random dRoll = new Random();
                           int d = dRoll.nextInt(6) + 1;
                           dieRolls[i] = d;
                        
                           for(int z=0; z < allP.size(); z++){
                           
                              if(allP.get(z).getCurrentRole().getType() == "On-Card"){
                                 allP.get(z).setMoney(dieRolls[i]);
                              }
                              else if(allP.get(z).getCurrentRole().getType() == "Off-Card"){
                                 allP.get(z).setMoney(allP.get(z).getCurrentRole().getReqRank());
                              
                              }
                           }
                        }
                     }
                  }
               }
            //--------------------------------------------------------------------------------------
            
            //-------------------------3. upgrade rank?---------------------------------------------
            
            // MY EDIT: player can only upgrade if they are in the casting office
               if(curPlayer.getCurrentRoom().getName() == "Casting Office"){
                  System.out.println("Player " + (j + 1) + " would you like to upgrade your rank? [yes/no]");
                  String in2 = reader.next();
                  if(in2.equals("yes")){
                  
                     if(curPlayer.getRank() == 6){    ///****EDIT****: else statement contains all logic until "if("no"){" statement 
                        System.out.println("You are already the max rank of 6"); ///****EDIT****
                     }else{ /////****EDIT****
                     
                     
                        int curRank = curPlayer.getRank();
                        int curMoney = curPlayer.getMoney();
                        int curFame = curPlayer.getFame();
                        System.out.println("Your Rank: " + curRank);
                        System.out.println("Your Money: $" + curRank);
                        System.out.println("Your Fame: " + curRank);
                        System.out.println("");
                        System.out.println("--------------------------------------------------------------");
                        System.out.println("----------------RANK UPGRADES AND COSTS-----------------------");
                        System.out.println("--------------------------------------------------------------");
                        System.out.println("|| New Rank || Money (cost) || Fame (cost) || ");
                        System.out.println("---------------------------------------------");
                        System.out.println("||    2     ||      $4      ||      5      || ");
                        System.out.println("||    3     ||      $10     ||      10     || ");
                        System.out.println("||    4     ||      $18     ||      15     || ");
                        System.out.println("||    5     ||      $28     ||      20     || ");
                        System.out.println("||    6     ||      $40     ||      25     || ");
                        System.out.println("---------------------------------------------");
                        System.out.println("Player " + (j + 1) + " which rank would you like to upgrade to?");
                        int in3 = reader.nextInt();
                        if(in3 <= curRank){
                           System.out.println("Your rank is " + curRank + ", choose a rank higher to upgrade to. [up to 6]"); 
                        
                        }else{
                           System.out.println("Would you like to use your fame or money to upgrade? [fame/money]"); 
                           String in4 = reader.next();
                           if(in4.equals("fame")){
                              if(curFame >= famePrices[in3][0]){
                                 curPlayer.setRank(in3);
                                 System.out.println("Nice! Your rank has been upgraded to rank " +  in3 + " !"); 
                              }else{
                                 System.out.println("Sorry not enough fame for this rank.");
                              }
                           }else if(in4.equals("money")){
                              if(curMoney >= moneyPrices[in3][0]){
                                 curPlayer.setMoney(-(moneyPrices[in3][0]));
                                 curPlayer.setRank(in3);
                                 System.out.println("Nice! Your rank has been upgraded to rank " +  in3 + " !");
                                 System.out.println("You have $" +  curPlayer.getMoney() + " left");
                              
                              }else{
                                 System.out.println("Sorry not enough money for this rank.");
                              }
                           }
                        }
                     }
                  }else if(in2.equals("no")){
                  
                  }
               }
            //--------------------------------------------------------------------------------------
            }
         }
         //End game
         if(daysLeft == 0){
            
            Moderator mod = new Moderator(allP.size());
            //Calculate final scores
            mod.calcScores(allP);
               
            //Declare winner
            Player winner = mod.declareWinner(allP);
            
            if(winner == null){
               System.out.println("Game Over! All players have the same score, you tied.");
            }
            else{  
               System.out.println("Game over! Congratulations "+winner.getColor()+" Player, you won!");
            }
            
         }
      }
   }
}

